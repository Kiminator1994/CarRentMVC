﻿using System.Windows.Media;

namespace WPF_Ui.Models
{
    public struct DataColor
    {
        public Brush Color { get; set; }
    }
}
