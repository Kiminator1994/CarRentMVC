﻿using CommunityToolkit.Mvvm.ComponentModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wpf.Ui.Common.Interfaces;

namespace WPF_Ui.ViewModels
{
    public class CustomerViewModel : ObservableObject, INavigationAware
    {
        
        public void OnNavigatedTo()
        {
            
        }

        public void OnNavigatedFrom()
        {
            
        }
    }
}
